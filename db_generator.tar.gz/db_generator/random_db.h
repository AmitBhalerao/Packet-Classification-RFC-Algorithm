// File: random_db.h
// David E. Taylor
// Applied Research Laboratory
// Department of Computer Science and Engineering
// Washington University in Saint Louis
// det3@arl.wustl.edu
//
// Generates a synthetic database af random filters

int random_db_gen(int num_filters, FilterList* filters);
